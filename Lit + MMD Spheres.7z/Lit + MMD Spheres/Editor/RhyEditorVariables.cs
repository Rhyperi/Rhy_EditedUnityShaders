using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace publicVariables
{
    public class shaderVariables
    {
        //Editor Variables
        public static string versionNumber = "2.0";
    }
}